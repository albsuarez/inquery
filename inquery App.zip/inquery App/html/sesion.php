<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Trabajo Fin de Grado</title>
    <!-- Favicon -->
    <link rel="icon" href="../img/tipo-inquery.png">
    <!-- CDN de Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!-- CDN Jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../form-css/css/main-2.css">
    <!-- CDN SweetAlert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body>

    <?php
    $codigo=$_GET['en'];
    // session_start();
?>

    <div class="container-contact100">
        <div class="wrap-contact100">
            <div class="wrap-input100">
                <img src="../img/inquery_black.png" class="masthead-brand" alt="" id="inic">
            </div>


            <div class="wrap-input100" style="text-transform:capitalize;">
                <span class="contact100-form-title" id="titulo"></span>
            </div>

            <div class="div-radiot">
                <div class="limiter">
                    <div class="container-table100">
                        <div class="wrap-table100">
                            <div class="table100">
                                <table id="tabla">
                                    <thead>
                                        <tr class="table100-head">
                                            <th class="column1">Código</th>
                                            <th class="column2">Título</th>
                                        </tr>
                                    </thead>
                                    <tbody id="trbody">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div id="botonesnav">
                    <input type="button" value="anterior" id="anterior" class="bnavega">
                    <input type="button" value="siguiente" id="siguiente" class="bnavega">
                    </div>
                    <div style="margin-top:25px;">
                        <span class="label-input100-nm">Selecciona una encuesta: </span>
                        <select class="label-input100" style="font-size:16px;" id="select">
                        </select>
                    </div>
                        <div class="wrap-input100" style="margin-top:5px;">
                            <input type="button" value="Acceder a Resultados" id="acceso"
                                class="container-contact100-form-bt contact100-form-bt">
                            <input type="button" value="Borrar Votación" id="enviar"
                                class="container-contact100-form-bt contact100-form-bt-borrar" style="margin-top:8px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" id="custId" name="custId" value='<?php echo $codigo?>'>
    <input id="numpagina" name="paginacion" type="hidden" value="0">

    <!--===============================================================================================-->
    <script src="../jquery/sesion_usuario.js"></script>
    <!--===============================================================================================-->

</body>

</html>