<!DOCTYPE html>
<html lang="es">

<head>
	<title>Formulario TFG</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="../img/tipo-inquery.png">
	<!--===============================================================================================-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
		integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../form-css/fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../form-css/vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../form-css/vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../form-css/css/main.css">
	<!--===============================================================================================-->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<!--===============================================================================================-->

</head>

<body id=body>
	<div class="clase_preloader" id=""><span class="" id="span_preloader"></span></div>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" action="../php/respuesta_registro.php" id="formulario">
				<span class="contact100-form-title" id="titulo">
					<img src="../img/inquery_black.png" class="masthead-brand" alt="">
				</span>

				<div class="wrap-input100  bg1">
					<span class="label-input100">Título o pregunta de la votación *</span>
					<input class="input100" type="text" name="titulo" id=""
						placeholder="Ej: ¿Cuál es tu restaurante preferido para la cena de empresa?">
				</div>

				<div class="wrap-input100 bg1">
					<span class="label-input100">Número de participantes *</span>
					<input class="input100" type="text" name="partici" id="" placeholder="Ej: 2 o más">
				</div>

				<div class="wrap-input100 bg1">
					<span class="label-input100">Comentario o descripción</span>
					<textarea class="input100" name="descripcion" id=""
						placeholder="La cena es el día 20 de Abril de 2020, el menú costará alrededor de 50€..."></textarea>
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Nombre *</span>
					<input class="input100" type="text" name="nombreusu" id="" placeholder="Steve Rogers">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Email *</span>
					<input class="input100" type="text" name="email" id="" placeholder="steve@dominio.com">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Opcion 1 de la votación *</span>
					<input class="input100" type="text" name="opcion1" id="" placeholder="McDonalds">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">Opcion 2 de la votación *</span>
					<input class="input100" type="text" name="opcion2" id="" placeholder="Telepizza">
				</div>

				<div class="container-contact100-form-bt" id="addopcion">
					<a class="contact100-form-bt">
						<span>
							Añadir Opciones
						</span>
					</a>
				</div>

				<div class="container-contact100-form-bt2" id="contequitar">
					<a class="contact100-form-bt2">
						<span>
							Quitar Opciones
						</span>
					</a>
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Identidad del participante *</span>
					<div>
						<select class="js-select2" name="confi1">
							<option value="0">Voto secreto</option>
							<option value="1">No secreto</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Permitir votar una sola opción o más de una *</span>
					<div>
						<select class="js-select2" name="confi2">
							<option value="0">Una sola opción</option>
							<option value="1">Más opciones</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Gráfica resultados *</span>
					<div>
						<select class="js-select2" name="confi3">
							<option value="1">Sí</option>
							<option value="0">No</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Acceso a los resultados de la votación *</span>
					<div>
						<select class="js-select2" name="confi4">
							<option value="0">Público</option>
							<option value="1">Sólo administrador</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<input type="submit" value="Crear votación" id="enviar" class="container-contact100-form-bt contact100-form-bt">

				<div id="mensaje"></div>

			</form>
		</div>
	</div>

	<!--===============================================================================================-->
	<script src="../jquery/jquery_formulario.js"></script>
	<!--===============================================================================================-->

	<script src="../form-css/vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function () {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});


			$(".js-select2").each(function () {
				$(this).on('select2:close', function (e) {
					if ($(this).val() == "Please chooses") {
						$('.js-show-service').slideUp();
					}
					else {
						$('.js-show-service').slideUp();
						$('.js-show-service').slideDown();
					}
				});
			});
		}) 	
	</script>

</body>
</html>