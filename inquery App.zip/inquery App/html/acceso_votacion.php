<!DOCTYPE html>
<html lang="es">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- aquí va el favicon -->
  <link rel="icon" href="../img/tipo-inquery.png">

  <title>Trabajo Fin de Grado</title>

  <!-- CSS de BootStrap CDN -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
    integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

  <!-- jQuery CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <!-- Enlace a nuestro CSS -->
  <link href="../css/acceso.css" rel="stylesheet">

  <!-- CDN SweetAlert -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body id="top">
  <div class="site-wrapper">
    <div class="site-wrapper-inner">
      <div class="cover-container">
        <div class="masthead clearfix">
          <div class="inner">
            <img src="../img/inquery.png" class="masthead-brand" id="titulo" style="" alt="">
          </div>
        </div>
        <div class="inner cover">
          <p class="lead cover-copy">
            <h1>Introduce el código de la votación</h1>
          </p>
          <br>
          <form method="POST" id="formulario" action="../php/check_acceso.php">
            <p class="lead"><input type="text" class="btn btn-lg btn-default btn-notify" data-toggle="modal" id="codigo"
                name="codigo" placeholder="Ej: 0123456"></p>
            <input type="submit" class="boton-default" id="boton_codigo" value="Acceder a la Votación">
          </form>
        </div>
        <div class="mastfoot">
        </div>
        <div class="modal fade" id="subscribeModal" tabindex="-1" role="dialog" aria-labelledby="subscribeModalLabel"
          aria-hidden="true">
        </div>
      </div>
    </div>
  </div>

  <script src="../jquery/jquery_acceso.js"></script>

</body>

</html>