<!DOCTYPE html>
<html lang="es">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- aquí va el favicon -->
  <link rel="icon" href="../img/tipo-inquery.png">
  <title>Trabajo Fin de Grado</title>
  <!-- CSS de BootStrap CDN -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
    integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
  <!-- jQuery CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!-- Enlace a nuestro CSS -->
  <link href="../css/sesion.css" rel="stylesheet">
  <!-- CDN SweetAlert -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body id="top">
  <div class="site-wrapper">
    <div class="site-wrapper-inner">
      <div class="cover-container">
        <div class="masthead clearfix">
          <div class="inner">
            <img src="../img/inquery.png" class="masthead-brand" id="titulo" style="weight:75px; height:60px;" alt="">
          </div>
        </div>
        <div class="inner cover">
          <form method="POST" id="formulario" action="../php/check_usuario.php">
            <p class="lead"><input type="text" style="cursor:text;" class="btn btn-lg btn-default btn-notify" id="usu"
                name="usuario" placeholder='Correo Electrónico'></p>
            <p class="lead"><input type="password" style="cursor:text;" class="btn btn-lg btn-default btn-notify"
                id="contra" name="password" placeholder='Contraseña'></p>
            <input type="button" class="boton-default" id="boton_recuperar" style="margin-top:8px;"
              value="Recuperar Contraseña">
            <input type="submit" class="boton-default" id="boton_codigo" style="margin-top:8px;" value="Iniciar Sesión">
          </form>
        </div>
        <div class="mastfoot">
        </div>
        <div class="modal fade" id="subscribeModal" tabindex="-1" role="dialog" aria-labelledby="subscribeModalLabel"
          aria-hidden="true">
        </div>
      </div>
    </div>
  </div>

  <script src="../jquery/sesion.js"></script>

</body>

</html>