<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Trabajo Fin de Grado</title>
    <!-- Favicon -->
    <link rel="icon" href="../img/tipo-inquery.png">
    <!-- CDN de Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!-- CDN Jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../form-css/fonts/iconic/css/material-design-iconic-font.min.css">
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../form-css/css/main-2.css">
    <!-- CDN SweetAlert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>

<body>

    <?php
        $codigo=$_GET['en'];
    ?>

    <div class="container-contact100">
        <div class="wrap-contact100">
            <div class="contact100-form-title" id="titu">
				<img src="../img/inquery_black.png" class="masthead-brand" alt="">
            </div>
            <div class="wrap-input100" style="text-transform:uppercase;">
                <span class="contact100-form-title" id="titulo"></span>
            </div>

            <div class="wrap-input100-2" style="text-align:center;">
                <span class="label-input100" id="descripcion" style="font-size:14px;"></span>
            </div>

            <div class="div-radiot">
                <div class="box" id="box">
                </div>
            </div>

            <div class="wrap-input100">
                <input type="button" value="Votar" id="enviar" class="contact100-form-bt" style="cursor:pointer;">
            </div>
        </div>
    </div>

    <input type="hidden" id="custId" name="custId" value='<?php echo $codigo?>'>

    <!--===============================================================================================-->
    <script src="../jquery/encuesta.js"></script>
    <!--===============================================================================================-->

</body>

</html>