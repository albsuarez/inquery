<!DOCTYPE html>
<html lang="es">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Trabajo Fin de Grado</title>
    <!-- Favicon -->
    <link rel="icon" href="../img/tipo-inquery.png">
    <!-- CDN de Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!-- CDN Jquery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="../form-css/css/main-3.css">
    <!-- CDN GOOGLE CHARTS -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

</head>

<body>

    <?php
    $codigo=$_GET['en'];
?>

    <div class="container-contact100">
        <div class="wrap-contact100">
            <span class="contact100-form-title-2" id="titu">
				<img src="../img/inquery_black.png" class="masthead-brand" alt="">
			</span>
            <div class="wrap-input100" style="text-transform:capitalize;">
                <span class="contact100-form-title" id="titulo"></span>
            </div>
            <div class="div-radiot">
                <div class="limiter">
                    <div class="container-table100">
                        <div class="table100">
                            <table>
                                <thead>
                                    <tr class="table100-head">
                                        <th class="column1">Opción</th>
                                        <th class="column2">Nº Votos</th>
                                    </tr>
                                </thead>
                                <tbody id="trbody">
                                </tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" id="custId" name="custId" value='<?php echo $codigo?>'>

    <!--===============================================================================================-->
    <script src="../jquery/resultado_vota.js"></script>
    <!--===============================================================================================-->

</body>

</html>