<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- aquí va el favicon -->
    <link rel="icon" href="img/tipo-inquery.png">

    <title>Trabajo Fin de Grado</title>

    <!-- CSS de BootStrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <!-- Enlace a nuestro CSS -->
    <link href="css/principal_index.css" rel="stylesheet">

    <!-- CDN de iconos CSS -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body id="top"><div class="site-wrapper">
  <div class="site-wrapper-inner">
    <div class="cover-container">
      <div class="masthead clearfix">
        <div class="inner">
          <img src="img/inquery.png" class="masthead-brand" style="weight:75px; height:60px;" alt="">
          <p class="iniciar-brand"><button type="button" class="btn btn-lg btn-default btn-notify" data-toggle="modal" id="sesion" style="font-size:15px; margin-top:15px; width:200px;">Iniciar Sesión</button></p>
        </div>
      </div><br><div class="inner cover">
        <!-- <h1 class="cover-heading"></h1> -->
        <p class="lead cover-copy"><h1>Crea votaciones, fácil y sencillo</h1></p>
        <p class="lead"><button type="button" class="btn btn-lg btn-default btn-notify-2" data-toggle="modal" id="boton_empezar" style="margin-top:15px;">Crear Votación</button></p>
        <p class="lead"><button type="button" class="btn btn-lg btn-default btn-notify" style="font-size:18px;" data-toggle="modal" id="acceder_encuesta">Acceder a Votación</button></p>
      </div>
      <div class="mastfoot">
      </div>
      <div class="modal fade" id="subscribeModal" tabindex="-1" role="dialog" aria-labelledby="subscribeModalLabel" aria-hidden="true"> 
          </div>
        </div>
    </div>
  </div>

    <!-- Aquí se integra Jquery
    ================================================== -->
    <!-- Se añade al final del documento porque se supone que va más rápido -->
    
    <!-- Línea de Jquery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Línea de Popper JS CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <!-- Línea de BootStrap CDN -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <!-- Línea de Script jQuery -->
    <script src="jquery/jquery_index.js"></script>

</body>
</html>