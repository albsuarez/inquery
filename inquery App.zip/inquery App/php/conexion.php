<?php
// Conexión con la DB
$usuario = "alberto";
$contraseña = "1234";
$dbname = "eleccion";
try{
    $dsn = "mysql:host=localhost;dbname=$dbname";
    $options = array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
      );
      $dbh = new PDO($dsn, $usuario, $contraseña);
}
catch(PDOException $e){
    echo "Fallo de la conexión". $e->getMessage();
    exit();
}
?>