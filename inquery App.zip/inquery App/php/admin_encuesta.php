<?php
include 'conexion.php';

$respuesta=array();

$codigo = empty( $_POST['codigo'] ) ? NULL : $_POST['codigo'];

if(!is_null($codigo))
{
    $stmt = $dbh->prepare("SELECT codigo FROM encuesta WHERE codigo=(:cod)");
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();
    
    if (!$stmt) {
        $respuesta[]="Ha habido un error en la consulta";
    } 
    else
    {
        $respuesta[]="correcto";
    }
}
else
{
    $respuesta[]="Selecciona un código";
}

echo json_encode($respuesta);
?>