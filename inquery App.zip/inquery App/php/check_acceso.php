<?php
include 'conexion.php';

$respuesta=array();

$codigo = empty( $_POST['codigo'] ) ? NULL : $_POST['codigo'];

if(!is_null($codigo))
{
    $stmt = $dbh->prepare("SELECT codigo, participantes, acceso FROM encuesta WHERE codigo=(:cod)");
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();
 
    if($row['codigo'] == $codigo){
        if($row['participantes'] == 0){
            if($row['acceso'] == 0){
                $respuesta[]='../html/resultado-votacion.php?en='.$codigo;
            }
            else
            {
                $respuesta[]="privada";
            }
        }
        else
        {
            $respuesta[]='../html/encuesta.php?en='.$codigo;
        }
    }
    else
    {
    $respuesta[]= "codigo incorrecto";
    }  
}
else
{
    $respuesta[]="Rellena todos los campos";
}

$dbh = null;
echo json_encode($respuesta);

?>