<?php
include 'conexion.php';
$codigo = empty($_POST['codigo'])?NULL:$_POST['codigo'];
$respuesta[]="comunicado con la respuesta";

echo json_encode($respuesta);
?>