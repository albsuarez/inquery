<?php
include 'conexion.php';

$respuesta=array();
$error=0;

$codigo = empty( $_POST['codigo'] ) ? NULL : $_POST['codigo'];

if(!is_null($codigo)) 
{
    $stmt = $dbh->prepare("SELECT titulo, voto_publi_anonimo, permitir_comentarios, una_o_mas_seleccion FROM encuesta WHERE codigo=(:cod)");
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();

    $respuesta[]=$row['titulo'];
    $respuesta[]=$row['voto_publi_anonimo'];
    $respuesta[]=$row['permitir_comentarios'];
    $respuesta[]=$row['una_o_mas_seleccion'];

}
echo json_encode($respuesta);
?>