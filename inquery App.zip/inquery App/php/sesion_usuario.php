<?php
include 'conexion.php';

$respuesta=array();
$codigo = empty($_POST['codigo'])?NULL:$_POST['codigo'];

if(!is_null($codigo))
{
    $stmt = $dbh->prepare("SELECT email, nombre FROM usuario WHERE cod_usu=(:cod)");
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();

    $email=$row['email'];
    $respuesta[]=$row['nombre'];
}

$stmt = $dbh->prepare("SELECT codigo, titulo FROM encuesta WHERE email=(:mail)");
$stmt->bindParam(':mail', $email);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$respuesta[]=$rows;


echo json_encode($respuesta);
?>
