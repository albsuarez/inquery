<?php
include 'conexion.php';
$respuesta=array();
$codigo = empty($_POST['codigo'])?NULL:$_POST['codigo'];

if(!is_null($codigo))
{
    $stmt = $dbh->prepare("SELECT codigo, titulo, descripcion, voto_publi_anonimo, una_o_mas_seleccion, permitir_comentarios FROM encuesta WHERE codigo=(:cod)");
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();
}

$respuesta[]=$row['codigo'];
$respuesta[]=$row['titulo'];
$respuesta[]=$row['descripcion'];
$respuesta[]=$row['voto_publi_anonimo'];
$respuesta[]=$row['una_o_mas_seleccion'];
$respuesta[]=$row['permitir_comentarios'];

echo json_encode($respuesta);
?>