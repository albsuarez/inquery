<?php
include 'conexion.php';

$respuesta=array();
$error=0;

$titulo = empty( $_POST['titulo'] ) ? NULL : ($_POST['titulo']); 
$partici = empty( $_POST['partici'] ) ? NULL : ($_POST['partici']);
$descripcion = empty( $_POST['descripcion'] ) ? NULL : ucfirst($_POST['descripcion']);
$nombreusu = empty( $_POST['nombreusu'] ) ? NULL : ($_POST['nombreusu']);
$email = empty( $_POST['email'] ) ? NULL : ($_POST['email']);
$confi1 = empty( $_POST['confi1'] ) ? NULL : ($_POST['confi1']);
$confi2 = empty( $_POST['confi2'] ) ? NULL : ($_POST['confi2']);
$confi3 = empty( $_POST['confi3'] ) ? NULL : ($_POST['confi3']);
$confi4 = empty( $_POST['confi4'] ) ? NULL : ($_POST['confi4']);

$op1 = empty( $_POST['opcion1'] ) ? NULL : ucwords($_POST['opcion1']);
$op2 = empty( $_POST['opcion2'] ) ? NULL : ucwords($_POST['opcion2']);
$op3 = empty( $_POST['opcion3'] ) ? NULL : ucwords($_POST['opcion3']);
$op4 = empty( $_POST['opcion4'] ) ? NULL : ucwords($_POST['opcion4']);
$op5 = empty( $_POST['opcion5'] ) ? NULL : ucwords($_POST['opcion5']);
$op6 = empty( $_POST['opcion6'] ) ? NULL : ucwords($_POST['opcion6']);
$op7 = empty( $_POST['opcion7'] ) ? NULL : ucwords($_POST['opcion7']);
$op8 = empty( $_POST['opcion8'] ) ? NULL : ucwords($_POST['opcion8']);
$op9 = empty( $_POST['opcion9'] ) ? NULL : ucwords($_POST['opcion9']);
$op10 = empty( $_POST['opcion10'] ) ? NULL : ucwords($_POST['opcion10']);

$opall = array($op1, $op2, $op3, $op4, $op5, $op6, $op7, $op8, $op9, $op10);
$opcion=array();

if(!is_null($titulo) && !is_null($descripcion) && !is_null($nombreusu) && !is_null($email) && !is_null($op1) && !is_null($op2) && !is_null($partici)){
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        if(preg_match("/^[a-zA-Z ]*$/",$nombreusu)){
            if($partici>=2){    
                //funcion que genera un codigo aleatorio de 6 dígitos
                $codigo="";
                $password="";
                for ($i=0;$i<6;$i++){
                    $codigo.=rand(0,9);
                }
                for ($i=0;$i<6;$i++){
                    $password.=rand(0,9);
                }

                // comprobar si un usuario ya existe en la BD
                $stmt = $dbh->prepare("SELECT email FROM usuario WHERE email=(:mail)");
                $stmt->bindParam(':mail', $email);
                $stmt->execute();
                $row = $stmt->fetch();
                if($row['email'] == $email){
                    $error = 1;
                }

                // comprobar si un codigo ya existe en Encuesta
                $stmt = $dbh->prepare("SELECT codigo FROM encuesta");
                $stmt->execute();
                $row = $stmt->fetch();
                if($row['codigo'] == $codigo){
                    while($row['codigo'] == $codigo){
                        for ($i=0;$i<6;$i++){
                            $codigo.=rand(0,9);
                        }
                    }
                }
        
                if($error==0){

                    $stmt = $dbh->prepare("INSERT INTO usuario(email, pass, nombre) VALUES(:email, :pass, :nom)");

                    $stmt->execute(array(
                        ':email' => "$email",
                        ':pass'  => "$password",
                        ':nom' => "$nombreusu"
                    ));

                    $stmt = $dbh->prepare("INSERT INTO encuesta(email, codigo, titulo, descripcion, voto_publi_anonimo, una_o_mas_seleccion, permitir_comentarios, participantes, acceso) VALUES(:email, :cod, :titu, :descr, :vpa, :uoms, :pc, :parti, :acce)");

                    if($stmt->execute(array(
                        ':email' => "$email",
                        ':cod'  => "$codigo",
                        ':titu' => "$titulo",
                        ':descr' => "$descripcion",
                        ':vpa' => "$confi1",
                        ':uoms' => "$confi2",
                        ':pc' => "$confi3",
                        ':parti' => "$partici",
                        ':acce' => "$confi4"
                    )))
                    {
                        include "class.phpmailer.php";
                        include "class.smtp.php";

                        $email_user = "albsuainc@gmail.com";
                        $email_password = "Alberto1995";
                        $the_subject = "Bienvenido a inQuery";
                        $address_to = $email;
                        $from_name = "inQuery";
                        $phpmailer = new PHPMailer();

                        // ---------- datos de la cuenta de Gmail -------------------------------
                        $phpmailer->Username = $email_user;
                        $phpmailer->Password = $email_password; 
                        //-----------------------------------------------------------------------
                        $phpmailer->SMTPSecure = 'ssl';
                        $phpmailer->Host = "smtp.gmail.com"; // GMail
                        $phpmailer->Port = 465;
                        $phpmailer->IsSMTP(); // use SMTP
                        $phpmailer->SMTPAuth = true;

                        $phpmailer->setFrom($phpmailer->Username,$from_name);
                        $phpmailer->AddAddress($address_to); // recipients email

                        $phpmailer->Subject = $the_subject;	
                        $phpmailer->Body .="<meta charset='ISO-8859-1'><h1 style='color:#3498db;'>Gracias por registrarte en inQuery!</h1>";
                        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>Tu usuario es el correo electrónico que has introducido y la contraseña es: ".$password.".</a></p><br><p>El código de acceso a la votación con el título '".$titulo."' es: <h3 style='color:#776a67;'>".$codigo."</h3><a href='http://localhost/TFG/html/encuesta.php?en=".$codigo."'>Pulsa aquí para ir directamente.</a></p><br><br><br><br><a href='https://wa.me/?text=inQuery%0A%0AEl%20código%20de%20acceso%20a%20la%20votación%20:".$titulo."%20es:%20".$codigo."'><img src='http://icons.iconarchive.com/icons/papirus-team/papirus-apps/256/whatsapp-icon.png' height='50px' weight='20px'></img></a>";
                        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
                        $phpmailer->IsHTML(true);
                        $phpmailer->CharSet = 'UTF-8';

                        $phpmailer->Send();

                        for($i=0;$i<=count($opall)-1;$i++){
                            if(!is_null($opall[$i])){
                                $opcion[]=array('opcion'=>$opall[$i], 'voto'=>0);
                            }
                        }

                        $encoded = json_encode($opcion);
                        file_put_contents('../json/'.$codigo.'.json', $encoded);
                        
                        $respuesta[]="correcto";
                        $respuesta[]=$codigo;
                    };
                }
                else
                {
                    //consulta que inserta la encuesta en la BD
                    $stmt = $dbh->prepare("INSERT INTO encuesta(email, codigo, titulo, descripcion, voto_publi_anonimo, una_o_mas_seleccion, permitir_comentarios, participantes, acceso) VALUES(:email, :cod, :titu, :descr, :vpa, :uoms, :pc, :parti, :acce)");

                    if($stmt->execute(array(
                        ':email' => "$email",
                        ':cod'  => "$codigo",
                        ':titu' => "$titulo",
                        ':descr' => "$descripcion",
                        ':vpa' => "$confi1",
                        ':uoms' => "$confi2",
                        ':pc' => "$confi3",
                        ':parti' => "$partici",
                        ':acce' => "$confi4"
                    )))
                    {
                        include "class.phpmailer.php";
                        include "class.smtp.php";

                        $email_user = "albsuainc@gmail.com";
                        $email_password = "Alberto1995";
                        $the_subject = "Votación creada";
                        $address_to = $email;
                        $from_name = "inQuery";
                        $phpmailer = new PHPMailer();

                        // ---------- datos de la cuenta de Gmail -------------------------------
                        $phpmailer->Username = $email_user;
                        $phpmailer->Password = $email_password; 
                        //-----------------------------------------------------------------------
                        $phpmailer->SMTPSecure = 'ssl';
                        $phpmailer->Host = "smtp.gmail.com"; // GMail
                        $phpmailer->Port = 465;
                        $phpmailer->IsSMTP(); // use SMTP
                        $phpmailer->SMTPAuth = true;

                        $phpmailer->setFrom($phpmailer->Username,$from_name);
                        $phpmailer->AddAddress($address_to); // recipients email

                        $phpmailer->Subject = $the_subject;	
                        $phpmailer->Body .="<meta charset='ISO-8859-1'><h1 style='color:#3498db;'>Gracias por utilizar inQuery!</h1>";
                        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>El código de acceso a la votación con el título '".$titulo."' es: <h3 style='color:#776a67;'>".$codigo."</h3><a href='http://localhost/TFG/html/encuesta.php?en=".$codigo."'>Pulsa aquí para ir directamente.</a></p><br><br><a href='https://wa.me/?text=inQuery%0A%0AEl%20código%20de%20acceso%20a%20la%20votación:%20".$titulo."%20es:%20".$codigo."'><img src='http://icons.iconarchive.com/icons/papirus-team/papirus-apps/256/whatsapp-icon.png' height='50px' weight='20px'></img></a>";
                        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
                        $phpmailer->IsHTML(true);
                        $phpmailer->CharSet = 'UTF-8';


                        $phpmailer->Send();

                        for($i=0;$i<=count($opall)-1;$i++){
                            if(!is_null($opall[$i])){
                                $opcion[]=array('opcion'=>$opall[$i], 'voto'=>0);
                            }
                        }

                        $encoded = json_encode($opcion);
                        file_put_contents('../json/'.$codigo.'.json', $encoded);

                        $respuesta[]="correcto";
                        $respuesta[]=$codigo;
                    };
                }
            }
            else
            {
                $respuesta[]="El número de participantes debe ser igual o mayor que 2";
            }
        }
        else
        {
            $respuesta[]="Nombre de usuario incorrecto";
        }
    }
    else
    {
        $respuesta[]="Introduce un email correcto";
    }
}  
else
{
    $respuesta[]="Rellena todos los campos obligatorios";
}

echo json_encode($respuesta);

?>