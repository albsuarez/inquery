<?php
include 'conexion.php';

$respuesta=array();

$email = empty( $_POST['usuario'] ) ? NULL : $_POST['usuario'];
$password = empty( $_POST['password'] ) ? NULL : $_POST['password'];

if(!is_null($usuario) && !is_null($password)) 
{
    $stmt = $dbh->prepare("SELECT cod_usu, email, pass FROM usuario WHERE email=(:email)");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $row = $stmt->fetch();
    
    if($row['pass'] == $password){
    $respuesta[]="correcto";
    $respuesta[]=$row['cod_usu'];
    }
    else
    {
    $respuesta[]= "codigo incorrecto";
    }
    
}
else
{
    $respuesta[]="Rellena todos los campos";
}

$dbh = null;
echo json_encode($respuesta);

?>