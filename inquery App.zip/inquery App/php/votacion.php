<?php
include 'conexion.php';
$respuestaAjax=array();
$respuesta = empty($_POST['respuesta'])?NULL:$_POST['respuesta'];
$codigo = empty($_POST['codigo'])?NULL:$_POST['codigo'];
$usuario = empty($_POST['usuario'])?NULL:$_POST['usuario'];

if(is_null($respuesta)){
    $respuesta="0";
}

$stmt = $dbh->prepare("SELECT participantes, acceso FROM encuesta WHERE codigo=(:cod)");
$stmt->bindParam(':cod', $codigo);
$stmt->execute();
$row = $stmt->fetch();
$respuestaAjax[]=$row['acceso'];

if($row['participantes'] != 0){
    
    $participantesResta = $row['participantes']-1;

    $stmt = $dbh->prepare("UPDATE encuesta SET participantes=(:partici) WHERE codigo=(:cod)");
    $stmt->bindParam(':partici', $participantesResta);
    $stmt->bindParam(':cod', $codigo);
    $stmt->execute();
    $row = $stmt->fetch();

    if(!is_null($usuario)){
        foreach ($respuesta as $i) {
            $json = file_get_contents("../json/".$codigo.".json");
            $obj = json_decode($json, true);

            $obj[$i]['voto']++;
            $objson = json_encode($obj);
            file_put_contents("../json/".$codigo.".json",$objson);
        }
          
            if(file_exists('../json-usuario/'.$codigo.'.json')){
                $jsonUsu = file_get_contents("../json-usuario/".$codigo.".json");
                $nom = json_decode($jsonUsu, true);
                $arrayJSON=array('respuesta'=>$respuesta, 'nombre'=>$usuario);
                array_push($nom, $arrayJSON);
                $nomjson = json_encode($nom);
                file_put_contents("../json-usuario/".$codigo.".json", $nomjson);
            }
            else
            {
                $arrayJSON=array();
                $arrayJSON[]=array('respuesta'=>$respuesta, 'nombre'=>$usuario);
                $encod = json_encode($arrayJSON);
                file_put_contents('../json-usuario/'.$codigo.'.json', $encod);
            }

        $respuestaAjax[]=$codigo;
    }
    else
    {
    foreach ($respuesta as $i) {
        $json = file_get_contents("../json/".$codigo.".json");
        $obj = json_decode($json, true);

        $obj[$i]['voto']++;
        $objson = json_encode($obj);
        file_put_contents("../json/".$codigo.".json",$objson);
    }
        $respuestaAjax[]=$codigo;
    }
}
else
{
    $respuestaAjax[]="agotada";
}

echo json_encode($respuestaAjax);
?>