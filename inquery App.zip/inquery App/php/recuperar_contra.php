<?php
include 'conexion.php';

$respuesta=array();

$email = empty( $_POST['usuario'] ) ? NULL : $_POST['usuario'];

if(!is_null($email)) 
{
    $stmt = $dbh->prepare("SELECT email, pass FROM usuario WHERE email=(:mail)");
    $stmt->bindParam(':mail', $email);
    $stmt->execute();
    $row = $stmt->fetch();

    if($row['email']==$email){

        $contraseña = $row['pass'];

        include "class.phpmailer.php";
        include "class.smtp.php";

        $email_user = "albsuainc@gmail.com";
        $email_password = "Alberto1995";
        $the_subject = "Recuperar Contraseña";
        $address_to = $email;
        $from_name = "inQuery";
        $phpmailer = new PHPMailer();

        // ---------- datos de la cuenta de Gmail -------------------------------
        $phpmailer->Username = $email_user;
        $phpmailer->Password = $email_password; 
        //-----------------------------------------------------------------------
        $phpmailer->SMTPSecure = 'ssl';
        $phpmailer->Host = "smtp.gmail.com"; // GMail
        $phpmailer->Port = 465;
        $phpmailer->IsSMTP(); // use SMTP
        $phpmailer->SMTPAuth = true;

        $phpmailer->setFrom($phpmailer->Username,$from_name);
        $phpmailer->AddAddress($address_to); // recipients email

        $phpmailer->Subject = $the_subject;	
        $phpmailer->Body .="<meta charset='ISO-8859-1'><h1 style='color:#3498db;'>Recuperación de la contraseña</h1>";
        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>La contraseña es: ".$contraseña.".</a></p>";
        $phpmailer->Body .= "<meta charset='ISO-8859-1'><p>Fecha y Hora: ".date("d-m-Y h:i:s")."</p>";
        $phpmailer->IsHTML(true);
        $phpmailer->CharSet = 'UTF-8';

        $phpmailer->Send();
        $respuesta[]="Te hemos enviado un correo de recuperación";
    }
    else
    {
        $respuesta[]="Introduce una dirección correcta";
    }
}
else
{
    $respuesta[]="Introduce una dirección correcta";
}
echo json_encode($respuesta);
?>