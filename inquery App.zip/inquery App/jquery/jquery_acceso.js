$("#formulario").submit(function (e) {
    e.preventDefault();
    var datosForm = $(this);

    $.ajax({
        type: 'POST',
        url: datosForm.attr('action'),
        dataType: "json",
        data: datosForm.serialize(),
        success: respuestaCorrecta,
        error: function (error) {
            $('.mensaje').append("Ha habido algún problema en la conexión");
        }
    });
});

function respuestaCorrecta(datos) {

    if (datos == "Rellena todos los campos") {
        swal('Rellena el campo');
    }
    else {
        if (datos == "codigo incorrecto") {
            swal('Código incorrecto');
        }
        else {
            if (datos == "privada") {
                swal({
                    title: "Sólo el administrador puede consultar los resultados",
                    text: "Pulsa Ok para ir al inicio",
                    icon: "success",
                    buttons: true,
                    })
                    .then((willDelete) => {
                    if (willDelete) {
                        setTimeout(function () { window.location.href = '../index.php'}, 500);
                    } else {
                    }
                    });
            }
            else {
                window.location.href = datos;
            }
        }
    }
};

$("#titulo").click(function(){
    window.location.href = '../index.php';
});

