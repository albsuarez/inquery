$(document).ready(function () {
    var codigo = $("#custId").val();
    var parametros = { "codigo": codigo };

    $.ajax({
        type: 'POST',
        url: '../php/resultado_votacion.php',
        dataType: "json",
        data: parametros,
        success: respuestaCorrecta,
        error: function (error) {
            console.log('ha habido un problema con la conexión');
        }
    });
});

function respuestaCorrecta(datos) {
    var codigo = $("#custId").val();
    var dataChart = []

    $("#titulo").html(datos[0]);

    if ((datos[1]) == 1) {

        $(".table100-head").append('<th class="column3">Nombre/s</th>');
        $.getJSON("../json/" + codigo + ".json", function (data) {
            $.each(data, function (i, value) {
                $("#trbody").append('<tr id="' + i + '"><th class="column1">' + value['opcion'] + '</th><th class="column2">' + value['voto'] + '</th></tr>');
                dataChart.push([value['opcion'], value['voto']]);
            });
            $.each(data, function (j, value) {
                $('#' + j).append('<th class="column3" id=th' + j + '></th>');
            });
        });

        $.getJSON("../json-usuario/" + codigo + ".json", function (data2) {
            $.each(data2, function (i, value) {
                $.each(value['respuesta'], function (j, voto) {
                    $('#th' + voto).append('' + value['nombre'] + '<br>');
                });
            });
        });
    }
    else {
        $.getJSON("../json/" + codigo + ".json", function (data) {
            $.each(data, function (i, value) {
                $("#trbody").append('<tr><th class="column1">' + value['opcion'] + '</th><th class="column2">' + value['voto'] + '</th></tr>');
                dataChart.push([value['opcion'], value['voto']]);
            });
        });
    }

    if ((datos[2]) == 1) {
        $(".table100").after('<div style="width: 100%; height: 500px;" id="grafico"><div id="chart_div" class="chart_pie"></div></div>');
    }

    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows(dataChart);

        var options = {
            width: '100%',
            height: '100%',
            legend: { position: 'bottom' },
            colors: ['#BBE884', '#9EB1EC', '#B56955', '#F3D6FF', '#FFF770', '#CC70B6', '#99267D', '#DAA6FF', '#FFF566', '#CCBD71']
        };

        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);

        function resizeHandler() {
            chart.draw(data, options);
        }
        if (window.addEventListener) {
            window.addEventListener('resize', resizeHandler, false);
        }
        else if (window.attachEvent) {
            window.attachEvent('onresize', resizeHandler);
        }
    }
};

$("#titu").click(function(){
    window.location.href = '../index.php';
});