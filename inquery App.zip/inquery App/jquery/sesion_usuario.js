var datosg = [];
var contadorpagina = 1;

$(document).ready(function () {
    var codigo = $("#custId").val();
    var parametros = { "codigo": codigo };

    $.ajax({
        type: 'POST',
        url: '../php/sesion_usuario.php',
        dataType: "json",
        data: parametros,
        success: respuestaCorrecta,
        error: function (error) {
            console.log('ha habido un problema con la conexión');
        }
    });

    function respuestaCorrecta(datos) {
        $("#titulo").html("Bienvenido " + datos[0]);
        $("#select").append('<option value="" disabled selected>código</option>');       
        if (datos[1].length>5){
        var num_registros = 1;
        var limite = num_registros + 5;
            for (num_registros; num_registros<limite; num_registros++) {
                var j = num_registros - 1;
                $("#trbody").append("<tr><td class='column1'>" + datos[1][j]['codigo'] + "</td><td class='column2'>" + datos[1][j]['titulo'] + "</td>");
                $("#select").append("<option value=" + datos[1][j]['codigo'] + ">" + datos[1][j]['codigo'] + "</option>");
            }
            datosg = datos[1];
        }
        else
        {
            $("#botonesnav").empty();
            $.each(datos[1], function (i, value) {
                $("#trbody").append("<tr><td class='column1'>" + value['codigo'] + "</td><td class='column2'>" + value['titulo'] + "</td>");
                $("#select").append("<option value=" + value['codigo'] + ">" + value['codigo'] + "</option>");
            });
        }       
    };
});

$("#siguiente").click(function(){
    $('#trbody').empty();
    var totalpaginas=Math.ceil(datosg.length/5);
    if(contadorpagina!=totalpaginas){
    contadorpagina++;
    }

    for (i=(contadorpagina-1)*5; i<(contadorpagina*5); i++) {
        if(i>=datosg.length){
            break;
        }
        $("#trbody").append("<tr><td class='column1'>" + datosg[i]['codigo'] + "</td><td class='column2'>" + datosg[i]['titulo'] + "</td>");
        $("#select").append("<option value=" + datosg[i]['codigo'] + ">" + datosg[i]['codigo'] + "</option>");
    }
    

});

$("#anterior").click(function(){
    $('#trbody').empty(); 
    if(contadorpagina!=1){
    contadorpagina--;
    }

    if(contadorpagina>Math.ceil(datosg.length/5)){
        contadorpagina=Math.ceil(datosg.length/5);
    }   

    for (i=(contadorpagina-1)*5; i<(contadorpagina*5); i++) {
        if(i>=datosg.length){
            break;
        }

        $("#trbody").append("<tr><td class='column1'>" + datosg[i]['codigo'] + "</td><td class='column2'>" + datosg[i]['titulo'] + "</td>");
        $("#select").append("<option value=" + datosg[i]['codigo'] + ">" + datosg[i]['codigo'] + "</option>");
    }
   
});

$("#enviar").click(function () {
    var select = $("#select").val();
    var parametros = { "codigo": select };

    if (select == null) {
        swal('Selecciona una opción');
    }
    else {
        swal({
            title: "¿Estás seguro?",
            text: "No podrás recuperar la votación",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    type: 'POST',
                    url: '../php/borrar_encuesta.php',
                    dataType: "json",
                    data: parametros,
                    success: respuestaCorrecta,
                    error: function (error) {
                        console.log('ha habido un problema con la conexión');
                    }
                });

                function respuestaCorrecta(datos) {
                    if (datos != "correcto") {
                        swal(datos[0]);
                    }
                    else {
                        location.reload();
                    }
                };
            } else {
              swal("No has borrado la votación!");
            }
          });
    }     
});

$("#acceso").click(function () {
    var select = $("#select").val();
    var parametros = { "codigo": select };

    $.ajax({
        type: 'POST',
        url: '../php/admin_encuesta.php',
        dataType: "json",
        data: parametros,
        success: respuestaCorrecta,
        error: function (error) {
            console.log('ha habido un problema con la conexión');
        }
    });

    function respuestaCorrecta(datos) {
        if (datos != "correcto") {
            swal(datos[0]);
        }
        else {
            setTimeout(function () {  window.open('../html/resultado-votacion.php?en=' + select)}, 100);
        }
    };
});

$("#inic").click(function () {
    window.location.href = '../index.php';
});
