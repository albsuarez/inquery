$("#formulario").submit(function (e) {
    e.preventDefault();
    var datosForm = $(this);

    $.ajax({
        type: 'POST',
        url: datosForm.attr('action'),
        dataType: "json",
        data: datosForm.serialize(),
        success: respuestaCorrecta,
        error: function (error) {
            $('.mensaje').append("Ha habido algún problema en la conexión");
        }
    });
});

function respuestaCorrecta(datos) {

    if (datos[0] == "Rellena todos los campos") {
        swal('Rellena todos los campos');
    }
    else {
        if (datos[0] == "codigo incorrecto") {
            swal('Email y/o contraseña incorrecta/s');
        }
        else {
            window.location.href = '../html/sesion.php?en=' + datos[1];
        }
    }
};

$("#boton_recuperar").click(function () {
    var usuario = $("#usu").val();
    var parametros = { "usuario": usuario };

    $.ajax({
        type: 'POST',
        url: '../php/recuperar_contra.php',
        dataType: "json",
        data: parametros,
        success: respuestaCorrecta,
        error: function (error) {
            console.log('ha habido un problema con la conexión');
        }
    });

    function respuestaCorrecta(datos) {
        swal(datos[0]);
    };
});

$("#titulo").click(function () {
    window.location.href = '../index.php';
});