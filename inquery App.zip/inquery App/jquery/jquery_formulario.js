var i = 3;
var j = 2;

$("#addopcion").click(function () {
    if (i < '11') {
        $("#addopcion").before('<div class="wrap-input100 bg1 rs1-wrap-input100" id="conte' + i + '"><span class="label-input100" id="span' + i + '">Opción ' + i + ' *</span><input class="input100" type="text" name="opcion' + i + '" id="opcion' + i + '"></div>');
        i++;
        j++;
    };
});

$("#contequitar").click(function () {
    $('#conte' + j + '').remove();
    $('#name' + j + '').remove();
    $('#opcion' + j + '').remove();

    if (j > '2') {
        j = j - 1;
    }
    if (i > '3') {
        i = i - 1;
    }
});

$("#formulario").submit(function (e) {
    $("#body").after('<div id="page-loader"><span class="preloader-interior" id="loader_id"></span></div>');
    e.preventDefault();
    var datosForm = $(this);

    $.ajax({
        type: 'POST',
        url: datosForm.attr('action'),
        dataType: "json",
        data: datosForm.serialize(),
        success: respuestaCorrecta,
        error: function (error) {
            $('.mensaje').append("Ha habido algún problema en la conexión");
        }
    });
});

function respuestaCorrecta(datos) {
    if (datos[0] == 'correcto') {
        window.location.href = './cod_votacion.php?en=' + datos[1];
    }
    else {
        $("div").remove("#page-loader");
        swal(datos[0]);
    }
};

$(".masthead-brand").click(function(){
    window.location.href = '../index.php';
});

