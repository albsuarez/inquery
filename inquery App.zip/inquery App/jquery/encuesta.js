$(document).ready(function () {
    var codigo = $("#custId").val();
    var parametros = { "codigo": codigo };

    $.ajax({
        type: 'POST',
        url: '../php/encuesta.php',
        dataType: "json",
        data: parametros,
        success: respuestaCorrecta,
        error: function (error) {
            console.log('ha habido un problema con la conexión');
        }
    });

    function respuestaCorrecta(datos) {
        $("#titulo").html(datos[1]);
        $("#descripcion").html(datos[2]);
        if (datos[3] === "1") {
            $(".div-radiot").after("<div class='wrap-input100-4'><span class='label-input100-nm'>Nombre *</span><input class='contact100-form-nm' type='text' name='usuario' id='usuarionombre' placeholder='Tony Stark'></div>");
        }

        if (datos[4] === "0") {
            $.getJSON("../json/" + datos[0] + ".json", function (data) {
                $.each(data, function (i, value) {
                    $("#box").append('<input type="radio" id="radio' + i + '" name="respuesta" value="' + i + '"/><label for="radio' + i + '">' + data[i].opcion + '</label>');
                });
            });
        }
        else {
            $.getJSON("../json/" + datos[0] + ".json", function (data) {
                $.each(data, function (i, value) {
                    $("#box").append('<input type="checkbox" name="respuesta" value="' + i + '" id="check' + i + '"><label class="check" for="check' + i + '">' + data[i].opcion + '</label>');
                });
                swal('Puedes seleccionar más de una opción');
            });
        }
    };
});


$("#enviar").click(function () {

    if (!$("input[name='respuesta']:checked").val()) {
        swal('Selecciona una opción');
        return false;
    }
    else {

        if ($("#usuarionombre")) {
            if ($('#usuarionombre').val() === '') {
                swal('Escribe un nombre');
            }
            else {
                var val = [];
                $("input[name='respuesta']:checked").each(function (i) {
                    val[i] = $(this).val();
                });

                var codigo = $("#custId").val();
                var usuario = $("#usuarionombre").val();
                var para = { "respuesta": val, "codigo": codigo, "usuario": usuario };


                $.ajax({
                    type: 'POST',
                    url: '../php/votacion.php',
                    dataType: "json",
                    data: para,
                    success: respuestaCorrecta,
                    error: function (error) {
                        console.log('ha habido un problema con la conexión');
                    }
                });
            }
        }
        else {
            var val = [];
            $("input[name='respuesta']:checked").each(function (i) {
                val[i] = $(this).val();
            });

            var codigo = $("#custId").val();
            var para = { "respuesta": val, "codigo": codigo };

            $.ajax({
                type: 'POST',
                url: '../php/votacion.php',
                dataType: "json",
                data: para,
                success: respuestaCorrecta,
                error: function (error) {
                    console.log('ha habido un problema con la conexión');
                }
            });
        }
    }
});

function respuestaCorrecta(datos) {
    var codigo = $("#custId").val();

    if (datos[1] != codigo) {
        if (datos[0] != 0){
            swal({
                title: "Votación agotada, Sólo el administrador puede consultar los resultados",
                text: "Pulsa Ok para ir al inicio",
                icon: "success",
                buttons: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    setTimeout(function () { window.location.href = '../index.php'}, 500);
                } else {
                }
                });
        }
        else
        {
            swal({
                title: "Votación agotada",
                text: "Pulsa Ok para ir a la página de resultados",
                icon: "success",
                buttons: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    setTimeout(function () { window.location.href = '../html/resultado-votacion.php?en=' + codigo; }, 500);
                } else {
                }
                });
        }
    }
    else {
        if (datos[0] != 0){
            swal({
                title: "Sólo el administrador puede consultar los resultados",
                text: "Pulsa Ok para ir al inicio",
                icon: "success",
                buttons: true,
                })
                .then((willDelete) => {
                if (willDelete) {
                    setTimeout(function () { window.location.href = '../index.php'}, 500);
                } else {
                }
                });
        }
        else
        {
            setTimeout(function () { window.location.href = '../html/resultado-votacion.php?en=' + codigo; }, 500);
        }
    }
};

$("#titu").click(function(){
    window.location.href = '../index.php';
});

