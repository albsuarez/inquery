$("#boton_empezar").click(function () {
    window.location.href = "./html/formulario.php";
});

$("#acceder_encuesta").click(function () {
    window.location.href = "./html/acceso_votacion.php";
});

$("#sesion").click(function () {
    window.location.href = "./html/usuario.php";
});